class CicloNegativoError(Exception):
    pass

def roteamento_microsservicos(grafo, vertices, origem, destino):
    distancias = {}
    predecessores = {}
    for v in vertices:
        distancias[v] = float('inf')
        predecessores[v] = None
    distancias[origem] = 0
    
    for i in range(len(vertices) - 1):
        for u in vertices:
            if distancias[u] == float('inf'):
                continue
            if u in grafo:
                for v in grafo[u]:
                    peso = grafo[u][v]
                    if distancias[u] + peso < distancias[v]:
                        distancias[v] = distancias[u] + peso
                        predecessores[v] = u
                    
    tem_ciclo_negativo = False
    for u in vertices:
        if distancias[u] == float('inf'):
            continue
        if u in grafo:
            for v in grafo[u]:
                peso = grafo[u][v]
                if distancias[u] + peso < distancias[v]:
                    tem_ciclo_negativo = True
                    break
        if tem_ciclo_negativo:
            break
            
    if tem_ciclo_negativo:
        raise CicloNegativoError("FALHA CRÍTICA: Ciclo negativo acidental detectado! Há um loop infinito de chamadas na arquitetura.")
        
    caminho = []
    atual = destino
    if distancias[destino] == float('inf'):
        return [], float('inf')
        
    while atual is not None:
        caminho.append(atual)
        atual = predecessores[atual]
    caminho.reverse()
    
    return caminho, distancias[destino]


vertices = ['API_Gateway', 'Auth_Service', 'Cache_Warmup', 'DB_Service', 'Processador', 'Finalizador']

grafo_valido = {
    'API_Gateway': {'Auth_Service': 10, 'Processador': 50},
    'Auth_Service': {'Cache_Warmup': 5},
    'Cache_Warmup': {'DB_Service': -20},
    'DB_Service': {'Processador': 15},
    'Processador': {'Finalizador': 5},
    'Finalizador': {}
}

grafo_invalido = {
    'API_Gateway': {'Auth_Service': 10},
    'Auth_Service': {'Processador': 5},
    'Processador': {'Cache_Warmup': -10},
    'Cache_Warmup': {'Auth_Service': -5},
    'Finalizador': {}
}

origem = 'API_Gateway'
destino = 'Finalizador'

print("=== Testando Arquitetura Válida ===")
try:
    rota, tempo_total = roteamento_microsservicos(grafo_valido, vertices, origem, destino)
    print("Rota ótima:", rota)
    print("Tempo total (com descontos):", tempo_total, "ms")
except CicloNegativoError as e:
    print(e)
    
print("\n=== Testando Arquitetura Inválida (Loop Infinito) ===")
try:
    rota, tempo_total = roteamento_microsservicos(grafo_invalido, vertices, origem, destino)
    print("Rota ótima:", rota)
except CicloNegativoError as e:
    print(e)
