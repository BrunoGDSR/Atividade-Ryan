def bellman_ford_arbitragem(grafo, vertices, origem):
    distancias = {}
    predecessores = {}
    for v in vertices:
        distancias[v] = float('inf')
        predecessores[v] = None
    distancias[origem] = 0
    
    for i in range(len(vertices) - 1):
        for u in vertices:
            if u in grafo:
                for v in grafo[u]:
                    peso = grafo[u][v]
                    if distancias[u] + peso < distancias[v]:
                        distancias[v] = distancias[u] + peso
                        predecessores[v] = u
                    
    for u in vertices:
        if u in grafo:
            for v in grafo[u]:
                peso = grafo[u][v]
                if distancias[u] + peso < distancias[v]:
                    visitados = []
                    atual = v
                    
                    while atual not in visitados:
                        visitados.append(atual)
                        atual = predecessores[atual]
                        
                    vertice_no_ciclo = atual
                    ciclo = [vertice_no_ciclo]
                    atual = predecessores[vertice_no_ciclo]
                    
                    while atual != vertice_no_ciclo:
                        ciclo.append(atual)
                        atual = predecessores[atual]
                        
                    ciclo.append(vertice_no_ciclo)
                    ciclo.reverse()
                    
                    return True, ciclo
                
    return False, []

vertices = ['Ouro', 'Prata', 'Cristal', 'Pocao']

grafo = {
    'Ouro': {'Prata': 0.5, 'Cristal': 1.0},
    'Prata': {'Pocao': -0.2},
    'Pocao': {'Cristal': -0.1},
    'Cristal': {'Ouro': -0.8}
}

print("=== Análise da Economia do Jogo ===")
tem_anomalia, ciclo_vicioso = bellman_ford_arbitragem(grafo, vertices, 'Ouro')

if tem_anomalia:
    print("ALERTA: Anomalia detectada na economia (Ciclo de Peso Negativo)!")
    print("Vértices do ciclo vicioso de lucro:", ciclo_vicioso)
else:
    print("A economia do jogo está balanceada. Nenhuma anomalia detectada.")
