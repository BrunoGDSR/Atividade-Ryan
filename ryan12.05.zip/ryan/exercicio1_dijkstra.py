import heapq

def dijkstra(grafo, origem, destino, aresta_bloqueada=None):
    distancias = {}
    predecessores = {}
    for v in grafo:
        distancias[v] = float('inf')
        predecessores[v] = None
    distancias[origem] = 0
    
    pq = [(0, origem)]
    
    while pq:
        dist_atual, u = heapq.heappop(pq)
        
        if dist_atual > distancias[u]:
            continue
            
        if u == destino:
            break
            
        for v in grafo[u]:
            peso = grafo[u][v]
            if aresta_bloqueada:
                u_b, v_b = aresta_bloqueada
                if (u == u_b and v == v_b) or (u == v_b and v == u_b):
                    continue
                    
            nova_dist = dist_atual + peso
            if nova_dist < distancias[v]:
                distancias[v] = nova_dist
                predecessores[v] = u
                heapq.heappush(pq, (nova_dist, v))
                
    caminho = []
    atual = destino
    if distancias[destino] == float('inf'):
        return [], float('inf')
        
    while atual is not None:
        caminho.append(atual)
        atual = predecessores[atual]
        
    caminho.reverse()
    return caminho, distancias[destino]

mapa = {
    'Manhuacu': {'Ouro Preto': 120, 'Joao Monlevade': 100},
    'Joao Monlevade': {'Manhuacu': 100, 'Belo Horizonte': 80, 'Mariana': 90},
    'Ouro Preto': {'Manhuacu': 120, 'Mariana': 30, 'Belo Horizonte': 95},
    'Mariana': {'Ouro Preto': 30, 'Joao Monlevade': 90, 'Belo Horizonte': 110},
    'Belo Horizonte': {'Joao Monlevade': 80, 'Ouro Preto': 95, 'Mariana': 110, 'Mineirao': 20},
    'Mineirao': {'Belo Horizonte': 20}
}

origem = 'Manhuacu'
destino = 'Mineirao'

print("=== CENÁRIO 1: Rota Normal ===")
rota, tempo = dijkstra(mapa, origem, destino)
print("Rota mais rápida:", rota)
print("Tempo total:", tempo, "minutos\n")

print("=== CENÁRIO 2: Acidente na rodovia (João Monlevade -> Belo Horizonte) ===")
aresta_bloqueada = ('Joao Monlevade', 'Belo Horizonte')
nova_rota, novo_tempo = dijkstra(mapa, origem, destino, aresta_bloqueada)
print("Aresta bloqueada:", aresta_bloqueada)
print("Nova rota ideal em tempo real:", nova_rota)
print("Novo tempo total:", novo_tempo, "minutos")
