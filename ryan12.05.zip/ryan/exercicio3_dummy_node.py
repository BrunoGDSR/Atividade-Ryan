import heapq

def dijkstra_multi_origem(grafo, fornecedores, destino):
    VERTICE_FICTICIO = 'Dummy'
    grafo[VERTICE_FICTICIO] = {}
    for f in fornecedores:
        grafo[VERTICE_FICTICIO][f] = 0
    
    distancias = {}
    predecessores = {}
    for v in grafo:
        distancias[v] = float('inf')
        predecessores[v] = None
    distancias[VERTICE_FICTICIO] = 0
    
    pq = [(0, VERTICE_FICTICIO)]
    
    while pq:
        dist_atual, u = heapq.heappop(pq)
        
        if dist_atual > distancias[u]:
            continue
            
        if u == destino:
            break
            
        for v in grafo[u]:
            peso = grafo[u][v]
            nova_dist = dist_atual + peso
            if nova_dist < distancias[v]:
                distancias[v] = nova_dist
                predecessores[v] = u
                heapq.heappush(pq, (nova_dist, v))
                
    caminho = []
    atual = destino
    if distancias[destino] == float('inf'):
        return [], float('inf')
        
    while atual is not None and atual != VERTICE_FICTICIO:
        caminho.append(atual)
        atual = predecessores[atual]
        
    caminho.reverse()
    
    return caminho, distancias[destino]

fornecedores = ['F1', 'F2', 'F3', 'F4']
destino = 'D'

grafo = {
    'F1': {'A': 50, 'B': 20},
    'F2': {'B': 10, 'C': 30},
    'F3': {'C': 15},
    'F4': {'A': 10, 'D': 100},
    'A': {'D': 40},
    'B': {'A': 10, 'C': 5},
    'C': {'D': 20},
    'D': {}
}

print("=== Otimização de Logística com Dummy Node ===")
rota, custo_total = dijkstra_multi_origem(grafo, fornecedores, destino)

if len(rota) > 0:
    melhor_fornecedor = rota[0]
    print("Melhor fornecedor:", melhor_fornecedor)
    print("Rota mais barata:", rota)
    print("Custo de frete total: R$", custo_total)
else:
    print("Não foi possível encontrar uma rota para o canteiro de obras.")
