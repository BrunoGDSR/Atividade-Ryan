import time
import random
import heapq

def dijkstra_simples(grafo, origem, destino):
    distancias = {}
    for v in grafo:
        distancias[v] = float('inf')
    distancias[origem] = 0
    pq = [(0, origem)]
    
    while pq:
        dist, u = heapq.heappop(pq)
        if dist > distancias[u]: 
            continue
        if u == destino: 
            break
        
        for v in grafo[u]:
            peso = grafo[u][v]
            if dist + peso < distancias[v]:
                distancias[v] = dist + peso
                heapq.heappush(pq, (distancias[v], v))
                
    return distancias[destino]

def bellman_ford_simples(grafo, origem, destino):
    vertices = list(grafo.keys())
    distancias = {}
    for v in vertices:
        distancias[v] = float('inf')
    distancias[origem] = 0
    
    for i in range(len(vertices) - 1):
        for u in vertices:
            if distancias[u] == float('inf'): 
                continue
            if u in grafo:
                for v in grafo[u]:
                    peso = grafo[u][v]
                    if distancias[u] + peso < distancias[v]:
                        distancias[v] = distancias[u] + peso
                    
    return distancias[destino]

def calcularRotaOtima(grafo, origem, destino):
    tem_negativo = False
    for u in grafo:
        for v in grafo[u]:
            peso = grafo[u][v]
            if peso < 0:
                tem_negativo = True
                break
        if tem_negativo: 
            break
        
    if tem_negativo:
        print("[Híbrido] Aresta de custo negativo detectada! Delegando para Bellman-Ford...")
        return bellman_ford_simples(grafo, origem, destino)
    else:
        print("[Híbrido] Apenas custos positivos. Delegando para Dijkstra...")
        return dijkstra_simples(grafo, origem, destino)

def gerar_grafo_grande(V, max_arestas_por_vertice=10):
    grafo = {}
    for i in range(V):
        grafo[i] = {}
        
    for i in range(V):
        num_arestas = random.randint(1, max_arestas_por_vertice)
        for j in range(num_arestas):
            v = random.randint(0, V-1)
            if v != i:
                grafo[i][v] = random.randint(1, 100)
    return grafo

print("=== Sistema Híbrido de Roteamento (Quatree Supreme) ===")

grafo_promocao = {
    'A': {'B': 10, 'C': 5},
    'B': {'D': -5},
    'C': {'D': 20},
    'D': {}
}

print("\nTeste 1: Grafo com promoção (Peso Negativo)")
custo1 = calcularRotaOtima(grafo_promocao, 'A', 'D')
print("Custo ótimo:", custo1)

print("\nTeste 2: Benchmark de Performance (Grafo Grande V=1500)")
V = 1500
print("Gerando grafo com", V, "vértices (apenas pesos positivos)...")
grafo_gigante = gerar_grafo_grande(V)
origem = 0
destino = V-1

print("\nIniciando Benchmark...")

inicio_d = time.time()
res_d = dijkstra_simples(grafo_gigante, origem, destino)
fim_d = time.time()
tempo_dijkstra = fim_d - inicio_d

inicio_b = time.time()
res_b = bellman_ford_simples(grafo_gigante, origem, destino)
fim_b = time.time()
tempo_bellman = fim_b - inicio_b

print("-" * 40)
print("Tempo Dijkstra:    ", round(tempo_dijkstra, 5), "segundos")
print("Tempo Bellman-Ford:", round(tempo_bellman, 5), "segundos")
print("-" * 40)

if tempo_dijkstra > 0:
    print("Dijkstra foi", round(tempo_bellman / tempo_dijkstra, 2), "x mais rápido!")
else:
    print("Dijkstra foi muito rápido para medir a diferença!")

print("PROVA: O overhead de varrer o grafo no início se paga enormemente evitando o Bellman-Ford quando não há pesos negativos.")
